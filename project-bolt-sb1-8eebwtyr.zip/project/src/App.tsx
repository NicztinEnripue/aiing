import React from 'react';
import { Shield, Lock, BrainCircuit as Circuit, Globe2, ChevronRight, ShieldAlert, Network, Key } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Animated background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(50,50,255,0.1),rgba(0,0,0,0.8))] animate-pulse"></div>

      {/* Hero Section */}
      <header className="relative container mx-auto px-4 py-24 text-center">
        <div className="flex justify-center mb-6">
          <Shield className="w-20 h-20 text-blue-500 animate-spin-slow" />
        </div>
        <h1 className="text-7xl font-bold mb-6 tracking-tight">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-600 animate-text">
            Nicztin
          </span>
        </h1>
        <p className="text-2xl text-blue-200/80 max-w-3xl mx-auto mb-12 leading-relaxed">
          Securing the digital frontier with advanced cybersecurity solutions. Protecting your future, today.
        </p>
        <a 
          href="#security-solutions" 
          className="group inline-flex items-center gap-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] active:scale-[0.98]"
        >
          Get Started
          <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </a>
      </header>

      {/* Features Grid */}
      <section id="security-solutions" className="relative container mx-auto px-4 py-24">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="group bg-gradient-to-br from-blue-950/50 to-black/50 p-8 rounded-2xl backdrop-blur-sm border border-blue-900/30 hover:border-blue-500/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(37,99,235,0.2)]">
            <ShieldAlert className="w-12 h-12 text-blue-400 mb-6 group-hover:text-blue-300 transition-colors" />
            <h3 className="text-2xl font-semibold mb-4 text-blue-100">Threat Detection</h3>
            <p className="text-blue-200/70">
              Advanced AI-powered systems that detect and neutralize cyber threats in real-time.
            </p>
          </div>

          <div className="group bg-gradient-to-br from-blue-950/50 to-black/50 p-8 rounded-2xl backdrop-blur-sm border border-blue-900/30 hover:border-blue-500/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(37,99,235,0.2)]">
            <Network className="w-12 h-12 text-blue-400 mb-6 group-hover:text-blue-300 transition-colors" />
            <h3 className="text-2xl font-semibold mb-4 text-blue-100">Network Security</h3>
            <p className="text-blue-200/70">
              Comprehensive network protection with advanced firewalls and intrusion prevention systems.
            </p>
          </div>

          <div className="group bg-gradient-to-br from-blue-950/50 to-black/50 p-8 rounded-2xl backdrop-blur-sm border border-blue-900/30 hover:border-blue-500/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(37,99,235,0.2)]">
            <Key className="w-12 h-12 text-blue-400 mb-6 group-hover:text-blue-300 transition-colors" />
            <h3 className="text-2xl font-semibold mb-4 text-blue-100">Encryption</h3>
            <p className="text-blue-200/70">
              Military-grade encryption protocols securing your sensitive data across all platforms.
            </p>
          </div>
        </div>
      </section>

      {/* Global Security Section */}
      <section className="relative container mx-auto px-4 py-24">
        <div className="bg-gradient-to-br from-blue-950/30 to-black/30 rounded-3xl overflow-hidden border border-blue-900/30">
          <div className="flex items-center justify-between p-12">
            <div className="w-1/2 pr-12">
              <h2 className="text-4xl font-bold mb-6 text-blue-100">Global Cybersecurity Network</h2>
              <p className="text-xl text-blue-200/70 mb-8">
                Our worldwide security operations centers provide 24/7 monitoring and instant threat response.
              </p>
              <div className="flex gap-4">
                <div className="bg-blue-500/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-blue-400">1000+</p>
                  <p className="text-blue-200/70">Threats Blocked Daily</p>
                </div>
                <div className="bg-blue-500/10 rounded-lg p-4">
                  <p className="text-3xl font-bold text-blue-400">99.99%</p>
                  <p className="text-blue-200/70">Detection Rate</p>
                </div>
              </div>
            </div>
            <div className="w-1/2 flex justify-center">
              <Globe2 className="w-64 h-64 text-blue-400 animate-float" />
            </div>
          </div>
        </div>
      </section>

      {/* Security Stats Section */}
      <section className="relative container mx-auto px-4 py-24">
        <div className="grid md:grid-cols-4 gap-8 text-center">
          <div className="bg-gradient-to-br from-blue-950/30 to-black/30 p-8 rounded-xl border border-blue-900/30">
            <p className="text-4xl font-bold text-blue-400 mb-2">200+</p>
            <p className="text-blue-200/70">Security Experts</p>
          </div>
          <div className="bg-gradient-to-br from-blue-950/30 to-black/30 p-8 rounded-xl border border-blue-900/30">
            <p className="text-4xl font-bold text-blue-400 mb-2">50+</p>
            <p className="text-blue-200/70">Countries Protected</p>
          </div>
          <div className="bg-gradient-to-br from-blue-950/30 to-black/30 p-8 rounded-xl border border-blue-900/30">
            <p className="text-4xl font-bold text-blue-400 mb-2">24/7</p>
            <p className="text-blue-200/70">Monitoring</p>
          </div>
          <div className="bg-gradient-to-br from-blue-950/30 to-black/30 p-8 rounded-xl border border-blue-900/30">
            <p className="text-4xl font-bold text-blue-400 mb-2">1M+</p>
            <p className="text-blue-200/70">Protected Systems</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative container mx-auto px-4 py-12 text-center text-blue-200/50">
        <p>© 2025 Nicztin. Securing the Digital Future.</p>
      </footer>
    </div>
  );
}

export default App;